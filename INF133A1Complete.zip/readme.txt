--Readme document for Natalie Pinto , *nvpinto@uci.edu*--

A reminder on academic integrity, as described in the syllabus.

In general, the course staff expects that you will look at code and examples from many online resources as part of the assignments, particularly to resolve syntax and understand frameworks. We expect that you'll use other libraries you find, and will even require it in some assignments. These practices are often critical to the work of developers today. The best developers are adept at interpreting the examples they see, customizing them to their specific situation, and citing their sources so they can find them later. We expect you to do the same.

While learning from examples is encouraged, attempting to pass an existing project or example from the web as your own is not allowed. If you ever have a question about what is or is not appropriate, feel free to ask the course staff!

Talking to classmates about class material, assignment requirements, etc. is a great way to verify ideas and get feedback. But this distinctly does *not* permit attempting to pass off someone else’s code as your own. Talking over ideas and approaches is allowed, but the work that you produce and submit must be your own.

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

10/10
- 1/1 Readme
- 2/2 Basic HTML content
- 1/1 Basic CSS styling
- 1/1 Advanced feature
- 2/2 Responsive layout
- 1/1 Passes validation checks
- 2/2 Embraces spirit of the assignment

2. What (a) basic features, (b) CSS features, and (c) advanced features did you include in your portfolio?

(a) Basic features

- At least one image, with descriptive alt attribute(s)
- Appropriate headings and paragraph text
- Links to external page(s)
- Semantic HTML tags like aside or footer


(b) CSS features

- Modifying padding and margins to indent content and enhance readability
- Modifying link, text color, or other colors to be visually appealing
- Leveraging Bootstrap CSS helpers such as image shapes and table layouts to display content in a more interesting manner


(c) Advanced features

- Creating a more complex page layout, such as including a sidebar or navigation bar
- Creating a table with multiple columns and rows which can be read via a screen reader
- Leveraging nested selectors to specify format


3. Did you ignore any of the warnings or errors presented by the accessibility checker? If so, why does this not seem like an accessibility concern? If it's useful, you can consolidate your thoughts on multiple warnings/errors if the rationale is similar.

    I had zero known problems when I used the HTML validator and I had zero known problems when using the CSS validator

4. How long, in hours, did it take you to complete this assignment?

    I spent about 7 hours to complete the assignment.

5. What online resources did you consult when completing this assignment? (list specific URLs, describe queries to Generative AI, or use of AI-based code completion)

    https://www.w3schools.com/howto/howto_website_create_portfolio.asp 
    How to create a portfolio using w3schools
    https://www.w3schools.com/howto/tryw3css_templates_portfolio.htm
    W3schools: My Portfolio Demo
    ChatGPT queries:
    "Can you provide a structure for the html and css code for an example UX/UI portfolio?"
    "Give me an example of a navigation bar using html and css"
    "Give me an example of a table using html and css"




6. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

    I Consulted a TA, Kaylee. She helped me fix a bug to display images in my browser. We also discussed ways I could get full points for "embrasing the spirit of the assignment" section

7. Is there anything special we need to know in order to run your code?

    No, thank you for allowing me to start my portfolio through this assignment. Very helpful!
